# uri-template

## Install

Via Composer

``` bash
$ composer require guzzlehttp/uri-template
```

## Change log

Please see [CHANGELOG](CHANGELOG.md) for more information on what has changed recently.

## Testing

``` bash
$ make test
```

## Security

If you discover any security related issues, please email security@guzzlephp.org instead of using the issue tracker.

## License

The MIT License (MIT). Please see [License File](LICENSE.md) for more information.
