<?php

declare(strict_types=1);

namespace Gym\Framework\Exception;

use Hyperf\Server\Exception\ServerException;

class AppException extends ServerException
{
}
