<?php

declare(strict_types=1);

namespace Gym\Framework\Listener;

use Hyperf\Database\Model\Events\Creating;
use Hyperf\Database\Model\Events\Event;
use Hyperf\Event\Annotation\Listener;
use Hyperf\Event\Contract\ListenerInterface;
use function Hyperf\Support\now;

#[Listener]
class CreateDataListener implements ListenerInterface
{
    public function listen(): array
    {
        return [
            Creating::class,
        ];
    }

    public function process(object $event): void
    {
        if ($event instanceof Event) {
            $model = $event->getModel();
            $model->created_at = now();
            $model->created_uid = 11;
            $model->updated_at = now();
            $model->updated_uid = 12;
        }
    }
}
