<?php

declare(strict_types=1);

namespace Gym\Framework\Listener;

use Hyperf\Database\Model\Events\Event;
use Hyperf\Database\Model\Events\Updating;
use Hyperf\Event\Annotation\Listener;
use Hyperf\Event\Contract\ListenerInterface;
use function Hyperf\Support\now;

#[Listener]
class UpdateDataListener implements ListenerInterface
{
    public function listen(): array
    {
        return [
            Updating::class,
        ];
    }

    public function process(object $event): void
    {
        if ($event instanceof Event) {
            $model = $event->getModel();
            $model->updated_at = now();
            $model->updated_uid = 12;
        }
    }
}
