<?php

declare(strict_types=1);

namespace Gym\Framework\Service;

use Hyperf\Database\Model\Builder;
use Hyperf\Database\Model\Model;

abstract class AbstractService
{
    /**
     * 添加单条
     */
    public function createData(array $data): Model
    {
        return $this->getModel()->create($data);
    }

    /**
     * 批量添加.
     * @param array $data 添加的数据
     * @return bool 执行结果
     */
    public function batchCreateData(array $data): bool
    {
        return $this->getModel()->insert($data);
    }

    /**
     * 多条
     * @param array $where 查询条件
     * @param array $columns 查询字段
     * @param array $options 可选项 ['orderByRaw'=> 'id asc']
     */
    public function getDataList(array $where, array $columns = ['*'], array $options = [])
    {
        # # 排序
        $orderBy = $options['orderBy'] ?? 'id desc';

        return $this->getDataQuery($where)
            ->select($columns)
            ->orderByRaw($orderBy)
            ->get();
    }

    /**
     * 多条分页.
     * @param array $where 查询条件
     * @param array $columns 查询字段
     * @param array $options 可选项 ['orderByRaw'=> 'id asc', 'perPage' => 15, 'page' => null]
     */
    public function getDataPageList(array $where, array $columns = ['*'], array $options = [])
    {
        # # 分页参数
        $perPage = $options['per_page'];
        $page = $options['page'];

        # # 排序
        $orderBy = $options['orderBy'] ?? 'id desc';

        return $this->getDataQuery($where)
            ->select($columns)
            ->orderByRaw($orderBy)
            ->forPage($page, $perPage)
            ->get();
    }

    /**
     * 查询单条
     */
    public function getDataDetail(array $where, array $columns = ['*']): null|Builder|Model
    {
        return $this->getDataQuery($where)->select($columns)->first();
    }

    /**
     * 查询总数.
     */
    public function getDataTotal(array $where): int
    {
        return $this->getDataQuery($where)->count();
    }

    /**
     * 更新数据.
     */
    public function updateData(array $where, array $data): int
    {
        return $this->getDataQuery($where)->update($data);
    }

    /**
     * 删除数据.
     * @return int|mixed
     */
    public function deleteData(array $where): mixed
    {
        return $this->getDataQuery($where)->delete();
    }

    /**
     * 抽象方法，用于获得当前服务类的模型.
     */
    abstract protected function getModel(): Model;

    /**
     * 查询条件.
     * @param mixed $query
     * @param array $where
     */
    protected function optionWhere(mixed $query, array $where): void
    {
        if (!empty($where)) {
            foreach ($where as $k => $v) {
                # # 一维数组
                if (!is_array($v)) {
                    $query->where($k, $v);
                    continue;
                }

                # # 二维索引数组
                if (is_numeric($k)) {
                    $v[1] = mb_strtoupper($v[1]);
                    $boolean = $v[3] ?? 'and';
                    if (in_array($v[1], ['=', '!=', '<', '<=', '>', '>=', 'LIKE', 'NOT LIKE'])) {
                        $query->where($v[0], $v[1], $v[2], $boolean);
                    } elseif ($v[1] == 'IN') {
                        $query->whereIn($v[0], $v[2], $boolean);
                    } elseif ($v[1] == 'NOT IN') {
                        $query->whereNotIn($v[0], $v[2], $boolean);
                    } elseif ($v[1] == 'RAW') {
                        $query->whereRaw($v[0], $v[2], $boolean);
                    }
                } else {
                    # # 二维关联数组
                    $query->whereIn($k, $v);
                }
            }
        }
    }

    abstract protected function getDataQuery($param): Builder;

    /**
     * 封装通用键值对查询条件.
     */
    protected function applyKeyFilters(mixed $query, mixed $param, mixed $keys): void
    {
        foreach ($keys as $key => $val) {
            if (isset($param[$val])) {
                $query->where(is_string($key) ? $key : $val, '=', $param[$val]);
            }
        }
    }
}
