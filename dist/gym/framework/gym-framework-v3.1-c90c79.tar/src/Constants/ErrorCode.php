<?php

declare(strict_types=1);

namespace Gym\Framework\Constants;

use Hyperf\Constants\Annotation\Constants;
use Hyperf\Constants\Annotation\Message;
use Hyperf\Constants\EnumConstantsTrait;

#[Constants]
enum ErrorCode: int
{
    use EnumConstantsTrait;

    #[Message('错误请求!')]
    case BAD_REQUEST = 400;

    #[Message('未授权!')]
    case UNAUTHORIZED = 401;

    #[Message('禁止访问!')]
    case FORBIDDEN = 403;

    #[Message('未找到数据!')]
    case NOT_FOUND = 404;

    #[Message('方法不允许!')]
    case METHOD_NOT_ALLOWED = 405;

    #[Message('请求过于频繁!')]
    case TOO_MANY_REQUESTS = 429;

    #[Message('内部服务器错误!')]
    case INTERNAL_SERVER_ERROR = 500;

    #[Message('服务不可用!')]
    case SERVICE_UNAVAILABLE = 503;

    #[Message('网关超时!')]
    case GATEWAY_TIMEOUT = 504;

    #[Message('错误网关!')]
    case BAD_GATEWAY = 502;

    #[Message('非法的参数')]
    public const INVALID_PARAMS = 422;
}
