<?php

declare(strict_types=1);

namespace Gym\Framework\Exception\Handler;

use Gym\Framework\Exception\BusinessException;
use Hyperf\Context\Context;
use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\ExceptionHandler\ExceptionHandler;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\HttpServer\Contract\RequestInterface;
use Hyperf\Validation\ValidationException;
use Psr\Http\Message\ResponseInterface;
use Psr\Log\LoggerInterface;
use Throwable;
use function Hyperf\Support\now;

class BusinessExceptionHandler extends ExceptionHandler
{
    // 控制台输出
    protected StdoutLoggerInterface $stdoutLogger;

    // 文件写入
    protected LoggerInterface $logger;

    protected RequestInterface $request;

    public function __construct(StdoutLoggerInterface $stdoutLogger, LoggerInterface $logger, RequestInterface $request)
    {
        $this->stdoutLogger = $stdoutLogger;
        $this->logger = $logger;
        $this->request = $request;
    }

    public function handle(Throwable $throwable, ResponseInterface $response)
    {
        // 判断被捕获到的异常是希望被捕获的异常
        if ($throwable instanceof BusinessException || $throwable instanceof ValidationException) {
            $request_id = Context::get('request_id');
            $error = [
                'request_at' => now()->toDateTimeString(), // 记录时间
                'request_id' => $request_id, // 请求ID
                'request_ip' => $this->request->header('X-Real-IP'), // 请求IP
                'method' => $this->request->getMethod(), // 请求方式
                'path' => $this->request->getPathInfo(), // 请求路径
                'file' => $throwable->getFile(), // 异常文件
                'line' => $throwable->getLine(), // 异常行号
                'message' => $throwable->getMessage(), // 异常信息
                'param' => $this->request->all(), // 请求参数
            ];
            $error = json_encode($error, JSON_UNESCAPED_SLASHES
                | JSON_UNESCAPED_UNICODE
                | JSON_PRESERVE_ZERO_FRACTION);
            $this->logger->error($error);
            $this->stdoutLogger->error($error);

            // 格式化输出
            $data = json_encode([
                'code' => $throwable->getCode(),
                'message' => $throwable->getMessage(),
                'data' => (object)[],
                'request_id' => $request_id,
            ], JSON_UNESCAPED_UNICODE);

            // 阻止异常冒泡
            $this->stopPropagation();
            return $response
                ->withAddedHeader('Content-Type', 'application/json;charset=utf-8')
                ->withStatus(400)
                ->withBody(new SwooleStream($data));
        }
        return $response;
    }

    public function isValid(Throwable $throwable): bool
    {
        return true;
    }
}
