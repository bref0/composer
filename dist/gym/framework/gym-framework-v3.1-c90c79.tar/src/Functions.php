<?php

declare(strict_types=1);

use Hyperf\Context\Context;

function success($data = [], $message = 'success'): array
{
    return ['code' => 200, 'message' => $message, 'data' => $data, 'request_id' => Context::get('request_id')];
}

if (!function_exists('responseDataFormat')) {
    function responseDataFormat($code, string $message = '', array $data = []): array
    {
        return [
            'code' => $code,
            'msg' => $message,
            'data' => $data,
        ];
    }
}

function getPaginate($data = []): array
{
    return [
        intval($data['per_page'] ?? 15),
        ['*'],
        'pageNo',
        intval($data['page'] ?? 1),
    ];
}

function uuid(): string
{
    $chars = md5(uniqid((string)mt_rand(), true));

    return substr($chars, 0, 8) . '-'
        . substr($chars, 8, 4) . '-'
        . substr($chars, 12, 4) . '-'
        . substr($chars, 16, 4) . '-'
        . substr($chars, 20, 12);
}

/**
 * 生成16位订单号.
 */
function create_order_no(): string
{
    $yCode = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

    return $yCode[intval(date('Y')) - 2011] . strtoupper(dechex((int)date('m'))) . date('d') . substr(
        (string)time(),
        -5
    ) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));
}

/**
 * 随机生成用户名.
 */
function randomName(): string
{
    $characters = array_merge(range('A', 'Z'), range('a', 'z'), range(0, 9));
    shuffle($characters);
    $random_chars = array_slice($characters, 0, 6);
    return implode('', $random_chars);
}

/**
 * 加解密字符串函数，可以加密中文
 * 加密:authcode('中文', 'ENCODE', 'abc');
 * 解密:authcode($encode, 'DECODE', 'abc');
 * 参数：$string：字符串，$operation：类别加密还是解密，$key：密钥.
 * @param mixed $string
 * @param mixed $operation
 * @return array|string|string[]
 */
function authCode($string, $operation, string $key = 'ab'): array|string
{
    $key = md5($key);
    $key_length = strlen($key);
    $string = $operation == 'DECODE' ? base64_decode($string) : substr(md5($string . $key), 0, 8) . $string;
    $string_length = strlen($string);
    $rndkey = $box = [];
    $result = '';
    for ($i = 0; $i <= 255; ++$i) {
        $rndkey[$i] = ord($key[$i % $key_length]);
        $box[$i] = $i;
    }
    for ($j = $i = 0; $i < 256; ++$i) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; ++$i) {
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ $box[($box[$a] + $box[$j]) % 256]);
    }
    if ($operation == 'DECODE') {
        if (substr($result, 0, 8) == substr(md5(substr($result, 8) . $key), 0, 8)) {
            return substr($result, 8);
        }
        return '';
    }
    return str_replace('=', '', base64_encode($result));
}

function moneyFormat($money): string
{
    return number_format((float)$money, 2, '.', '');
}
