<?php

declare(strict_types=1);

namespace Gym\Framework\Listener;

use Hyperf\Database\Model\Events\Deleting;
use Hyperf\Database\Model\Events\Event;
use Hyperf\Event\Annotation\Listener;
use Hyperf\Event\Contract\ListenerInterface;
use function Hyperf\Support\now;

#[Listener]
class DeleteDataListener implements ListenerInterface
{
    public function listen(): array
    {
        return [
            Deleting::class,
        ];
    }

    public function process(object $event): void
    {
        if ($event instanceof Event) {
            $model = $event->getModel();
            $model->deleted_at = now();
            $model->deleted_uid = 13;
        }
    }
}
