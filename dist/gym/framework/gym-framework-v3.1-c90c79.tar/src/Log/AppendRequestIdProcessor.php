<?php

declare(strict_types=1);

namespace Gym\Framework\Log;

use Hyperf\Coroutine\Coroutine;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Monolog\LogRecord;
use Monolog\Processor\ProcessorInterface;
use function Hyperf\Support\env;

class AppendRequestIdProcessor implements ProcessorInterface
{
    #[Inject]
    protected RequestInterface $request;

    public function __invoke(array|LogRecord $record)
    {
        if (env('APP_ENV') == 'prod') {
            $record['extra']['request_ip'] = $this->request->header('X-Real-IP') ?? '';
        }
        $record['extra']['coroutine_id'] = Coroutine::id();
        return $record;
    }
}
