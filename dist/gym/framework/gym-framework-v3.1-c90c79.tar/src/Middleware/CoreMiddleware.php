<?php

declare(strict_types=1);

namespace Gym\Framework\Middleware;

use Gym\Framework\Constants\ErrorCode;
use Gym\Framework\Exception\BusinessException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Swow\Psr7\Message\ResponsePlusInterface;

class CoreMiddleware extends \Hyperf\HttpServer\CoreMiddleware
{
    protected function handleNotFound(ServerRequestInterface $request): ResponseInterface
    {
        // 重写路由找不到的处理逻辑
        throw new BusinessException(ErrorCode::NOT_FOUND);
    }

    protected function handleMethodNotAllowed(array $methods, ServerRequestInterface $request): ResponsePlusInterface
    {
        // 重写 HTTP 方法不允许的处理逻辑
        throw new BusinessException(ErrorCode::METHOD_NOT_ALLOWED);
    }
}
