<?php

declare(strict_types=1);

namespace Gym\Framework\Model;

use Carbon\Carbon;
use Hyperf\Database\Model\Relations\HasOne;
use Hyperf\Database\Model\SoftDeletes;
use Hyperf\DbConnection\Model\Model;
use Hyperf\ModelCache\Cacheable;
use Hyperf\ModelCache\CacheableInterface;

abstract class AbstractModel extends Model implements CacheableInterface
{
    use Cacheable;
    use SoftDeletes;

    protected array $guarded = [];

    protected array $casts = [
        'created_at' => 'datetime:Y-m-d H:i:s',
        'updated_at' => 'datetime:Y-m-d H:i:s',
    ];

    public function createUser(): HasOne
    {
        return $this->hasOne(Account::class, 'id', 'created_uid');
    }

    public function updateUser(): HasOne
    {
        return $this->hasOne(Account::class, 'id', 'updated_uid');
    }

    public function getCreatedAtAttribute($value): string
    {
        return $value == '0000-00-00 00:00:00' ? '' : Carbon::parse($value)->toDateTimeString();
    }

    public function getUpdatedAtAttribute($value): string
    {
        return $value == '0000-00-00 00:00:00' ? '' : Carbon::parse($value)->toDateTimeString();
    }

    public function getDeletedAtAttribute($value): string
    {
        return $value == '0000-00-00 00:00:00' ? '' : Carbon::parse($value)->toDateTimeString();
    }
}
