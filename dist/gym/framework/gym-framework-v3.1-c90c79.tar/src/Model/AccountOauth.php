<?php

declare(strict_types=1);

namespace Gym\Framework\Model;


use Carbon\Carbon;

/**
 * @property int $id
 * @property string $deletedAt
 * @property int $deletedUid
 * @property Carbon $updatedAt
 * @property int $updatedUid
 * @property Carbon $createdAt
 * @property int $createdUid
 * @property int $uid 账号id
 * @property int $oauthType 平台类型
 * @property string $oauthId 平台ID
 */
class AccountOauth extends AbstractModel
{
    protected ?string $table = 'account_oauth';

    protected array $casts = ['id' => 'integer', 'deleted_uid' => 'integer', 'updated_at' => 'datetime', 'updated_uid' => 'integer', 'created_at' => 'datetime', 'created_uid' => 'integer', 'uid' => 'integer', 'oauth_type' => 'integer'];
}
