<?php

declare(strict_types=1);

namespace Gym\Framework\Service;

use Gym\Framework\Constants\ErrorCode;
use Gym\Framework\Exception\BusinessException;
use Carbon\Carbon;
use Hyperf\Di\Annotation\Inject;
use Psr\SimpleCache\CacheInterface;
use Psr\SimpleCache\InvalidArgumentException;
use function Hyperf\Support\env;
use function Hyperf\Support\now;

class TokenService
{
    #[Inject]
    protected CacheInterface $cacheService;

    /**
     * 生成 Token.
     *
     * @throws InvalidArgumentException
     */
    public function generateToken(int $user_id, int $valid_days = 3, string $type = 'token'): array
    {
        $authKey = env('AUTH_KEY');
        $expired_at = Carbon::now()->addDays($valid_days)->toDateTimeString();
        $key = json_encode([
            'user_id' => $user_id,
            'expired_at' => $expired_at,
        ]);
        $token = authCode($key, 'ENCODE', $authKey);

        $this->cacheService->set("{$type}:{$user_id}", $token, $expired_at);

        return [
            'token' => 'Bearer ' . $token,
            'expired_at' => $expired_at,
        ];
    }

    /**
     * 验证 Token.
     *
     * @throws InvalidArgumentException
     */
    public function validateToken(string $token, string $type = 'token'): mixed
    {
        $authKey = env('AUTH_KEY');
        $token = str_replace('Bearer ', '', $token);
        $authData = authCode($token, 'DECODE', $authKey);

        if (!$authData) {
            throw new BusinessException(ErrorCode::UNAUTHORIZED, 'Token 格式错误');
        }

        $authData = json_decode($authData, true);
        if ($authData['expired_at'] < now()->toDateTimeString()) {
            throw new BusinessException(ErrorCode::UNAUTHORIZED, 'Token 已过期');
        }

        $checkToken = $this->cacheService->get("{$type}:" . $authData['user_id']);
        if (!$checkToken) {
            throw new BusinessException(ErrorCode::UNAUTHORIZED, 'Token 已作废');
        }

        if ($checkToken !== $token) {
            throw new BusinessException(ErrorCode::UNAUTHORIZED, 'Token 已更新');
        }

        return $authData['user_id'];
    }
}
