<?php

declare(strict_types=1);

namespace Gym\Framework\Middleware;

use Gym\Framework\Service\TokenService;
use Hyperf\Context\Context;
use Hyperf\Di\Annotation\Inject;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\SimpleCache\InvalidArgumentException;

class JwtMiddleware implements MiddlewareInterface
{
    #[Inject]
    protected TokenService $tokenService;

    /**
     * @throws InvalidArgumentException
     */
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $token = $request->getHeader('Authorization')[0] ?? '';
        $userId = $this->tokenService->validateToken($token);
        $request = $request->withAttribute('user_id', $userId);
        Context::set(ServerRequestInterface::class, $request);
        return $handler->handle($request);
    }
}
