<?php

declare(strict_types=1);

namespace Gym\Framework\Model;

use Carbon\Carbon;

/**
 * @property int $id
 * @property string $deletedAt
 * @property int $deletedUid
 * @property Carbon $updatedAt
 * @property int $updatedUid
 * @property Carbon $createdAt
 * @property int $createdUid
 * @property string $username 用户名
 * @property string $mobile 手机号
 * @property string $createIp 创建ip
 * @property string $lastLoginAt 最后一次登录时间
 * @property string $lastLoginIp 最后一次登录ip
 * @property int $loginTimes 登录次数
 */
class Account extends AbstractModel
{
    protected ?string $table = 'account';
}
