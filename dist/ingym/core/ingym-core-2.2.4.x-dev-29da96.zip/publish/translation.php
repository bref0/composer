<?php

declare(strict_types=1);

return [
    'locale' => 'zh_CN',
    'fallback_locale' => 'en',
    'path' => BASE_PATH . '/vendor/ingym/core/publish/languages',
];
