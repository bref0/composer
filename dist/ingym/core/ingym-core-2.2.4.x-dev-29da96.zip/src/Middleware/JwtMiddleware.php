<?php

declare(strict_types=1);

namespace Ingym\Core\Middleware;

use Hyperf\Di\Annotation\Inject;
use Hyperf\Utils\Context;
use Ingym\Core\Constants\HttpCode;
use Ingym\Core\Exception\AppException;
use Phper666\JWTAuth\JWT;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Throwable;

class JwtMiddleware implements MiddlewareInterface
{
    protected string $prefix = 'Bearer ';

    /**
     * @Inject
     */
    protected JWT $jwt;

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $token = $request->getHeader('Authorization')[0] ?? '';
        if (strlen($token) > 0) {
            $token = str_replace($this->prefix, '', $token);

            try {
                $this->jwt->verifyToken($token);
                $data = $this->jwt->getClaimsByToken($token);
                //表示不是团购H5登陆
//            if (isset($claim['user_code'])) {
//                $container = ApplicationContext::getContainer();
//                $redis = $container->get(Redis::class);
//                $redisValue = $redis->sIsMember('onlineUser', $claim['user_code']);
//                if (!$redisValue) {
//                    return [
//                        'code' => -1,
//                        'msg' => '无效的鉴权!!'
//                    ];
//                }
//            }
                //更改上下文，写入jwt信息
                $request = $request->withAttribute('user', $data);
                Context::set(ServerRequestInterface::class, $request);
            } catch (Throwable $e) {
                throw new AppException(HttpCode::UNAUTHORIZED, $e->getMessage());
            }
        } else {
            throw new AppException(HttpCode::UNAUTHORIZED, '无鉴权信息');
        }
        return $handler->handle($request);
    }
}
