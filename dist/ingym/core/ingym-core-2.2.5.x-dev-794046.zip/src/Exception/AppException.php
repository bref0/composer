<?php

namespace Ingym\Core\Exception;

use Hyperf\Server\Exception\ServerException;
use Ingym\Core\Constants\HttpCode;
use Throwable;

class AppException extends ServerException
{
    public function __construct(int $code = 0, string $message = null, Throwable $previous = null)
    {
        if (is_null($message)) {
            $message = HttpCode::getMessage($code);
        }

        parent::__construct($message, $code, $previous);
    }
}
