# 核心依赖库

## 安装 
`composer require ingym/core`

## 发布语言包
`php bin/hyperf.php vendor:publish ingym/core`

