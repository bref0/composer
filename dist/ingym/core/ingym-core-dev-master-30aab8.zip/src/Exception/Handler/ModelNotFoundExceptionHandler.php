<?php

declare(strict_types=1);

namespace Ingym\Core\Exception\Handler;

use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\Database\Model\ModelNotFoundException;
use Hyperf\ExceptionHandler\ExceptionHandler;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\HttpServer\Contract\RequestInterface;
use Ingym\Core\Constants\HttpCode;
use Psr\Http\Message\ResponseInterface;
use Throwable;

class ModelNotFoundExceptionHandler extends ExceptionHandler
{
    protected StdoutLoggerInterface $logger;
    protected RequestInterface $request;

    public function __construct(StdoutLoggerInterface $logger, RequestInterface $request)
    {
        $this->logger = $logger;
        $this->request = $request;
    }


    public function handle(Throwable $throwable, ResponseInterface $response): ResponseInterface
    {
        if ($throwable instanceof ModelNotFoundException) {
            // 判断被捕获到的异常是希望被捕获的异常
            $data = json_encode([
                'code' => HttpCode::NOT_FOUND,
                'msg' => HttpCode::getMessage(HttpCode::NOT_FOUND),
            ], JSON_UNESCAPED_UNICODE);

            // 阻止异常冒泡
            $this->stopPropagation();

            return $response
                ->withStatus(HttpCode::NOT_FOUND)
                ->withHeader('Server', env('APP_NAME'))
                ->withAddedHeader('content-type', 'application/json; charset=utf-8')
                ->withBody(new SwooleStream($data));
        }
        return $response;
    }

    public function isValid(Throwable $throwable): bool
    {
        return true;
    }
}
