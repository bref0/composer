<?php

declare(strict_types=1);

namespace Ingym\Core\Middleware;

use Hyperf\Utils\Context;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

class FilterParamsMiddleware implements MiddlewareInterface
{
    protected ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        //全局中间件 将前端传来的数据去空格
        $method = $request->getMethod();
        if (strtolower($method) == 'get') {
            $parseData = $request->getQueryParams();
        } else {
            $parseData = $request->getParsedBody();
        }
        $filteredParams = [];
        foreach ($parseData as $key => $value) {
            //空字符转成 null
            $value = (is_string($value) && $value === '') ? null : $value;
            //如果是null 就直接扔掉
            if (is_null($value)) {
                continue;
            }
            //如果是字符串 那么就去空 否则保留原样
            $filteredParams[$key] = is_string($value) ? trim($value) : $value;
        }
        if (strtolower($method) == 'get') {
            $request = $request->withQueryParams($filteredParams);
        } else {
            $request = $request->withParsedBody($filteredParams);
        }
        Context::set(ServerRequestInterface::class, $request);
        return $handler->handle($request);
    }
}
