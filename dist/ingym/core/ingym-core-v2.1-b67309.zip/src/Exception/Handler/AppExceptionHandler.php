<?php

declare(strict_types=1);

namespace Ingym\Core\Exception\Handler;

use Ingym\Core\Exception\AppException;
use Ingym\Core\Utils\Log;
use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\ExceptionHandler\ExceptionHandler;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\HttpServer\Contract\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use Throwable;

class AppExceptionHandler extends ExceptionHandler
{
    protected StdoutLoggerInterface $logger;

    protected RequestInterface $request;

    public function __construct(StdoutLoggerInterface $logger, RequestInterface $request)
    {
        $this->logger = $logger;
        $this->request = $request;
    }

    public function handle(Throwable $throwable, ResponseInterface $response): ResponseInterface
    {
        if ($throwable instanceof AppException) {
            $content = [
                'auth' => $this->request->getAttribute('user') ?? [], //鉴权
                'param' => $this->request->getQueryParams(),
                'body' => $this->request->getParsedBody(),
            ];
            $error = sprintf(
                '%s||%s||%s||%s||%s',
                $this->request->getMethod(),//请求方法
                $this->request->getUri(),//请求地址
                $throwable->getFile(),//报错文件
                $throwable->getLine(),//报错文件行
                $throwable->getMessage(),//报错信息
            );
            //输出到控制台
            $this->logger->error($error);
            $this->logger->error(json_encode($content, JSON_UNESCAPED_UNICODE));
            //记录到文件
            Log::get()->error($error, $content);

            $data = json_encode([
                'code' => $throwable->getCode(),
                'msg' => $throwable->getMessage(),
            ], JSON_UNESCAPED_UNICODE);

            // 阻止异常冒泡
            $this->stopPropagation();

            return $response
                ->withHeader('Server', env('APP_NAME'))
                ->withAddedHeader('content-type', 'application/json; charset=utf-8')
                ->withBody(new SwooleStream($data));
        }
        // 交给下一个异常处理
        return $response;
    }

    public function isValid(Throwable $throwable): bool
    {
        return true;
    }
}
