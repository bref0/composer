<?php

declare(strict_types=1);

namespace Ingym\Core\Constants;

use Hyperf\Constants\AbstractConstants;
use Hyperf\Constants\Annotation\Constants;

/**
 * @Constants
 * @method static string getMessage($code)
 */
class ApproveType extends AbstractConstants
{
    /**
     * @Message("会籍特价审批")
     */
    const APPROVE_MC_CONTRACT_SPECIAL = 7;

    /**
     * @Message('定金延期审批')
     */
    const APPROVE_EA_DELAY = 1;

    /**
     * @Message('定金财务退款审批')
     */
    const APPROVE_EA_REFUND = 20;

    /**
     * @Message('团课教练修改审批')
     */
    const APPROVE_CLASS_UPDATE = 2;

    /**
     * @Message('其他财务退款审批')
     */
    const APPROVE_OTHER_REFUND = 3;

    /**
     * @Message("会籍转让审批")
     */
    const APPROVE_MC_CONTRACT_TRANSFER = 11;

    /**
     * @Message("合同结转审批")
     */
    const APPROVE_CONTRACT_CHARGE = 12;

    /**
     * @Message("会籍延期开卡审批")
     */
    const APPROVE_MC_CONTRACT_DELAY_OPEN = 18;

    /**
     * @Message("会籍修改通店审批")
     */
    const APPROVE_MC_CONTRACT_CHANGE_SHOP = 24;

    /**
     * @Message("会籍业绩分单审批")
     */
    const APPROVE_MC_RP_SPLIT = 14;

    /**
     * @Message('会籍财务退款审批')
     */
    const APPROVE_MC_CONTRACT_REFUND = 21;

    /**
     * @Message("私教合同名称修改审批")
     */
    const APPROVE_PT_UPDATE_ITEM = 47;

    /**
     * @Message("私教特价审批")
     */
    const APPROVE_PT_CONTRACT_SPECIAL = 4;

    /**
     * @Message("私教转让审批")
     */
    const APPROVE_PT_CONTRACT_TRANSFER = 5;

    /**
     * @Message("私教转店审批")
     */
    const APPROVE_PT_CONTRACT_TRANSFER_SHOP = 6;

     /**
     * @Message("私教业绩分单审批")
     */
    const APPROVE_PT_RP_SPLIT = 15;

    /**
     * @Message('私教财务退款审批')
     */
    const APPROVE_PT_CONTRACT_REFUND = 19;

    /**
     * @Message("游泳特价审批")
     */
    const APPROVE_SW_CONTRACT_SPECIAL = 8;

    /**
     * @Message("游泳转让审批")
     */
    const APPROVE_SW_CONTRACT_TRANSFER = 9;

    /**
     * @Message("游泳转店审批")
     */
    const APPROVE_SW_CONTRACT_TRANSFER_SHOP = 10;

     /**
     * @Message("游泳业绩分单审批")
     */
    const APPROVE_SW_RP_SPLIT = 16;

    /**
     * @Message('游泳财务退款审批')
     */
    const APPROVE_SW_CONTRACT_REFUND = 22;

    /**
     * @Message("舞蹈特价审批")
     */
    const APPROVE_DC_CONTRACT_SPECIAL = 29;

    /**
     * @Message("舞蹈转让审批")
     */
    const APPROVE_DC_CONTRACT_TRANSFER = 30;

    /**
     * @Message("舞蹈转店审批")
     */
    const APPROVE_DC_CONTRACT_TRANSFER_SHOP = 31;

    /**
     * @Message("舞蹈业绩分单审批")
     */
    const APPROVE_DC_RP_SPLIT = 37;

    /**
     * @Message("舞蹈财务退款审批")
     */
    const APPROVE_DC_REFUND = 35;

    /**
     * @Message("篮球特价审批")
     */
    const APPROVE_LQ_CONTRACT_SPECIAL = 42;

    /**
     * @Message("篮球转让审批")
     */
    const APPROVE_LQ_CONTRACT_TRANSFER = 43;

    /**
     * @Message("篮球转店审批")
     */
    const APPROVE_LQ_CONTRACT_TRANSFER_SHOP = 44;

    /**
     * @Message("篮球业绩分单审批")
     */
    const APPROVE_LQ_RP_SPLIT = 45;

    /**
     * @Message("篮球财务退款审批")
     */
    const APPROVE_LQ_REFUND = 46;

    /**
     * @Message("羽毛球特价审批")
     */
    const APPROVE_YMQ_CONTRACT_SPECIAL = 32;

    /**
     * @Message("羽毛球转让审批")
     */
    const APPROVE_YMQ_CONTRACT_TRANSFER = 33;

    /**
     * @Message("羽毛球转店审批")
     */
    const APPROVE_YMQ_CONTRACT_TRANSFER_SHOP = 34;

     /**
     * @Message("羽毛球业绩分单审批")
     */
    const APPROVE_YMQ_RP_SPLIT = 23;

    /**
     * @Message('羽毛球财务退款审批')
     */
    const APPROVE_YMQ_REFUND = 36;

    /**
     * @Message("修改支付方式审批")
     */
    const APPROVE_MODIFY_PAYMENT = 17;

     /**
     * @Message("会员资料修改审批")
     */
    const APPROVE_MEMBER_EDIT = 13;
}
