<?php

declare(strict_types=1);

namespace Ingym\Core;

use Hyperf\Contract\TranslatorInterface;
use Hyperf\Contract\TranslatorLoaderInterface;
use Hyperf\Translation\FileLoaderFactory;
use Hyperf\Translation\TranslatorFactory;

class ConfigProvider
{
    public function __invoke(): array
    {
        return [
            // 合并到  config/autoload/dependencies.php 文件
            'dependencies' => [
                TranslatorLoaderInterface::class => FileLoaderFactory::class,
                TranslatorInterface::class => TranslatorFactory::class,
            ],
            'commands' => [
            ],
            // 合并到  config/autoload/annotations.php 文件
            'annotations' => [
                'scan' => [
                    'paths' => [
                        __DIR__,
                    ],
                ],
            ],
            'publish' => [
                [
                    'id' => 'config',
                    'description' => '鉴权配置',
                    'source' => __DIR__ . '/../publish/jwt.php',
                    'destination' => BASE_PATH . '/config/autoload/jwt.php',
                ],
                [
                    'id' => 'config',
                    'description' => '日志配置',
                    'source' => __DIR__ . '/../publish/logger.php',
                    'destination' => BASE_PATH . '/config/autoload/logger.php',
                ],
                [
                    'id' => 'config',
                    'description' => '翻译',
                    'source' => __DIR__ . '/../publish/translation.php',
                    'destination' => BASE_PATH . '/config/autoload/translation.php',
                ],
                [
                    'id' => 'zh_CN',
                    'description' => '中文语言包',
                    'source' => __DIR__ . '/../publish/languages/zh_CN/validation.php',
                    'destination' => BASE_PATH . '/storage/languages/zh_CN/validation.php',
                ],
                [
                    'id' => 'en',
                    'description' => '英文语言包',
                    'source' => __DIR__ . '/../publish/languages/en/validation.php',
                    'destination' => BASE_PATH . '/storage/languages/en/validation.php',
                ],
            ],
        ];
    }
}
