<?php

declare(strict_types=1);

namespace Ingym\Core\Constants;

use Hyperf\Constants\AbstractConstants;
use Hyperf\Constants\Annotation\Constants;

/**
 * @Constants
 * @method static string getMessage($code)
 */
class HttpCode extends AbstractConstants
{
    /**
     * @Message("未知错误")
     */
    const UNKNOWN_ERROR = 0;

    /**
     * @Message("请求成功")
     */
    const OK = 200;

    /**
     * @Message("请求错误")
     */
    const BAD_REQUEST = 400;

    /**
     * @Message("鉴权错误")
     */
    const UNAUTHORIZED = 401;

    /**
     * @Message("资源未找到")
     */
    const NOT_FOUND = 404;

    /**
     * @Message("服务器错误")
     */
    const SERVER_ERROR = 500;
}
