<?php

namespace Illuminate\Mail\Mailables;

use Illuminate\Mail\Attachment as BaseAttachment;

class Attachment extends BaseAttachment
{
    // Here for namespace consistency...
}
