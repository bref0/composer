# Release Notes for 9.x

## [Unreleased](https://github.com/laravel/framework/compare/v9.0.0...9.x)


## [v9.0.0 (2021-??-??)](https://github.com/laravel/framework/compare/v8.79.0...v9.0.0)

Check the upgrade guide in the [Official Laravel Upgrade Documentation](https://laravel.com/docs/9.x/upgrade). Also you can see some release notes in the [Official Laravel Release Documentation](https://laravel.com/docs/9.x/releases).
