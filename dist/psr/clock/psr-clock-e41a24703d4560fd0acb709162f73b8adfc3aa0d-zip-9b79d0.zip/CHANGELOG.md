# Changelog

All notable changes to this project will be documented in this file, in reverse chronological order by release.

## 1.0.0

First stable release after PSR-20 acceptance

## 0.1.0

First release
