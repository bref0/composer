<?php

/**
 * Test bootstrap
 *
 * @codingStandardsIgnoreFile
 */

// Ensure floating-point precision is set to 14 (the default) for tests.
ini_set('precision', '14');

require_once __DIR__ . '/../vendor/autoload.php';
