<?php

class Normalizer extends Symfony\Polyfill\Intl\Normalizer\Normalizer
{
}
