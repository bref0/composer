Symfony Polyfill / Php83
========================

This component provides features added to PHP 8.3 core:

- [`json_validate`](https://wiki.php.net/rfc/json_validate)

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/main/README.md).

License
=======

This library is released under the [MIT license](LICENSE).
