<?php

return array (
  'foo' => 'bar',
);
