Changelog
=========

* 1.0.0 (2015-05-12)

 * first stable release

* 1.0.0-beta (2015-03-19)

 * first beta release
